//create global varibles
//create an object of the Phaser.Game called game
var game = new Phaser.Game(800,600,Phaser.AUTO,"my-game",{
	preload: preload,
	create: create,
	update: update
});

//global varibles
var logo;
var spacebar;
var hello1,hello2,hello3;
var score = 0;
var scoreText,matchText;
var match2Sound,match3Sound;

// required functions
function preload(){
	//game.load.image('phaser-logo','assets/phaser.png');
	//loading a spritesheet called hello that is the file of hello-sprite, that are 64,64
	game.load.spritesheet('hello','assets/hello-sprite.png',64,64)
	
	game.load.audio('spin','assets/spinner.mp3')
	game.load.audio('coin','assets/coin.wav')
	game.load.audio('pu','assets/power-up.wav')
}

function create(){
	//			game.add.image(x,y,image)
	//logo = game.add.image(400,300,'phaser-logo');
	//logo.anchor.setTo(0.5,0.5);
	hello1 = game.add.sprite(game.world.centerX - 100,game.world.centerY,'hello');
	hello2 = game.add.sprite(game.world.centerX,game.world.centerY,'hello');
	hello3 = game.add.sprite(game.world.centerX + 100,game.world.centerY,'hello');
	
	hello1.anchor.set(0.5,0.5);
	hello2.anchor.set(0.5,0.5);
	hello3.anchor.set(0.5,0.5);
	
	spacebar = game.input.keyboard.addKey(Phaser.KeyCode.SPACEBAR);

	spinSound = game.add.audio('spin',0.3);
	match2Sound = game.add.audio('coin',0.5);
	match3Sound = game.add.audio('pu',0.75);
	spinSound.loop = true;

	scoreText = game.add.text(game.world.centerX, game.world.centerY + 80,
        'Use Spacebar to Spin',
        { font: 'Arial', fontSize: '20px', fontStyle: 'bold', fill: '#ffffff' });
    scoreText.setShadow(1, 1, '#000000', 2);
    matchText = game.add.text(game.world.centerX+50, game.world.centerY + 80,
        '',
        { font: 'Arial', fontSize: '20px', fontStyle: 'bold', fill: '#ffffff' });
    matchText.setShadow(1, 1, '#000000', 2);
}

//this runs every single frame
function update() {
    if (spacebar.justDown) {
        spinSound.play();
		matchText.text="";
    }
    else if (spacebar.isDown) {
        hello1.frame = Math.floor(Math.random() * 6);
        hello2.frame = Math.floor(Math.random() * 6);
        hello3.frame = Math.floor(Math.random() * 6);
    }
    else if (spacebar.justUp) {
        spinSound.stop();
		checkMatch();
		game.stage.backgroundColor = Phaser.Color.getRandomColor();
    }  
}

//custom functions
function checkMatch() {
    
    if (hello1.frame == hello2.frame && hello2.frame == hello3.frame) {
        // all 3 match
        score = score + 100;
        match3Sound.play();
        matchText.fill = '#00ff00';
        matchText.text='Match Two +20'
    }
    else if (hello1.frame == hello2.frame || hello2.frame == hello3.frame
    || hello1.frame == hello3.frame) {
        // any 2 match
        score = score + 20;
        match2Sound.play();
        matchText.fill = '#00ff00';
        matchText.text='Match Two +20'
    }
    else {
        // none match
        score = score - 10;
        matchText.fill = '#00ff00';
        matchText.text='Match Two +20'
    }
    scoreText.text = score;
}






/*
	Block
		Comment
*/